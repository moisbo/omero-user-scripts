try:
    import pexpect
    from pexpect import *
except ImportError:
    from _pexpect import *
